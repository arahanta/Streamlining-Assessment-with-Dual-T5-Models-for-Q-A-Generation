import styled from 'styled-components';

// Define the styled component for the outer div
export const StyledAbhishek = styled.div`
    /* CSS styles for the outer div */
    @import url("https://candyfonts.com/wp-data/2018/10/26/11538/HELR45W.ttf");
*{
    font-family: 'helvetica';
 }
    .abhishek {
        /* CSS styles for the 'abhishek' class */
        margin-left: 100px;
        margin-top: 50px;
        margin-right: 792px;
        background-color: #F4E0E9;
        border-radius: 80px;
    }
`;

// Define the styled component for the h1 tag
export const StyledH1 = styled.h1`
    /* CSS styles for h1 tag */
    margin-left: 50px;
    margin-right: 50px;
    margin-top: 40px;
    display: inline-block;
    text-align: justify;
`;

// Define the styled component for the p tag
export const StyledP = styled.p`
    /* CSS styles for p tag */
    margin-top: 20px;
    margin-left: 50px;  
`;

// Define the styled component for the p1 tag
export const StyledP1 = styled.p`
    /* CSS styles for p1 tag */
    margin-bottom: 40px;
    margin-left: 50px;
    display: inline-block;
`;