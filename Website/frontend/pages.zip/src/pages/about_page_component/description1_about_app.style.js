import styled from 'styled-components';

// Define the styled component for the outer div
export const StyledDiv = styled.div`
    /* CSS styles for the outer div */
    @import url("https://candyfonts.com/wp-data/2018/10/26/11538/HELR45W.ttf");
*{
    font-family: 'helvetica';
 }
    .des{
        margin-left: 100px;
        margin-right: 100px;
        margin-top: 50px;
        background-color: #F4E0E9;
        border-radius: 80px;
        }
`;

export const StyledH1 = styled.h1`
    /* CSS styles for h1 tag */
    margin-left: 470px;
    margin-right: 50px;
    margin-top: 30px;
    display: inline-block;
    text-align: justify;
`;

export const StyledP1 = styled.p`
    /* CSS styles for p1 tag */
    margin-left: 50px;
    margin-right: 50px;
    margin-top: 20px;
    display: inline-block;
    text-align: justify;
`;

export const StyledP2 = styled.p`
    /* CSS styles for p2 tag */
    margin-left: 50px;
    margin-right: 50px;
    display: inline-block;
    text-align: justify;
`;

export const StyledP3 = styled.p`
    /* CSS styles for p3 tag */
    margin-left: 50px;
    margin-right: 50px;
    margin-bottom: 50px;
    display: inline-block;
    text-align: justify;
`;