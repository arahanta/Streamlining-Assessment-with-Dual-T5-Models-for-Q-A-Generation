import { StyledRishav, StyledH1, StyledP, StyledP1 } from "./rishav.style.js";

// Rishav component
const Rishav = () => {
    return (
        <StyledRishav>
            <div className="rishav">
                <StyledH1>Rishav Subedi</StyledH1>
                <StyledP>Level: BE Computer 4th Year</StyledP>
                <StyledP>Contact: </StyledP>
                <StyledP1>E-mail: </StyledP1>
            </div>
        </StyledRishav>
    );
};

export default Rishav;
