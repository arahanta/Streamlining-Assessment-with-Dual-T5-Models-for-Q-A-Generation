import styled from 'styled-components';

// Define the styled component for the outer div
export const StyledDeveloper = styled.div`
    /* CSS styles for the outer div */
    @import url("https://candyfonts.com/wp-data/2018/10/26/11538/HELR45W.ttf");
*{
    font-family: 'helvetica';
 }
    .developer {
        /* CSS styles for the 'developer' class */
        margin-left: 478px;
        margin-top: 50px;
        margin-right: 468px;
        background-color: #F4E0E9;
        border-radius: 80px;
    }
`;

// Define the styled component for the h1 tag
export const StyledH1 = styled.h1`
    /* CSS styles for h1 tag */
    margin-left: 30px;
    margin-top: 20px;
    display: inline-block;
    margin-bottom: 25px;
`;