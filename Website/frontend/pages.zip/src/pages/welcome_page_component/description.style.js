import styled from 'styled-components';

export const StyledDescription = styled.div`
/* Styles for description */
@import url("https://candyfonts.com/wp-data/2018/10/26/11538/HELR45W.ttf");
*{
    font-family: 'helvetica';
 }
.description {
    margin-top: 110px;
    margin-left: 80px;
    margin-right: 690px;
  }

  .welcome1 {
    font-size: 30px;
    font-weight: bolder;
  }

  .welcome2 {
    font-size: 16px;
  }
`;