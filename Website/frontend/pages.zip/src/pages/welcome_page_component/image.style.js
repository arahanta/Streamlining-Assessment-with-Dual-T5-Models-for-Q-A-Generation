import styled from 'styled-components';

export const StyledImages = styled.div`
/* Styles for images */
  .image {
    margin-left: 1220px;
  }

  img {
    height: 70px;
    cursor: pointer;
  }
`;
