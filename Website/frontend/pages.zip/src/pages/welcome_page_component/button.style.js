import styled from 'styled-components';

export const StyledButton = styled.div`
/*Styles for button*/
  .sign {
    margin-left: 70px;
  }

  .start {
    margin-top: 7px;
    margin-left: 10px;
    position: absolute;
  }

  .nav-link {
    display: inline-block;
    padding: 10px 20px;
    font-size: 16px;
    text-decoration: none;
    background-color: #D179FF; 
    border-radius: 15px;
    transition: background-color 0.3s ease-in-out;
  }

  .nav-link:hover {
    background-color: #9D53E3; 
  }
`;