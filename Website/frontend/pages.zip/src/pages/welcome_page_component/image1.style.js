import styled from 'styled-components';

// Define the styled component for the outer div
export const StyledImageContainer = styled.div`
    /* CSS styles for the outer div */
    .image1{
        margin-left: 50vw;
        margin-top: -2000px;
        overflow: hidden;
        border-radius: 130px;
        display: inline-block;
        position: relative;
    }
`;

// Define the styled component for the image
export const StyledImage = styled.img`
    /* CSS styles for the image */
`;