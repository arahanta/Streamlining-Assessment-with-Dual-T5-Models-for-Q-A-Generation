//import different components of homepage
import Form from "./home_component/form";
import Footer from "./home_component/footer/footer";
import FooterLogo from "./home_component/footer/footer_logo";
import SocialMedia from "./home_component/footer/social_media";
import FooterInfo from "./home_component/footer/monologue";
import Contact from "./home_component/footer/contact";


const Home = () => {
    return (
        <div>
            <Form />
            <Footer />
            <FooterLogo />
            <SocialMedia />
            <FooterInfo />
            <Contact />
        </div>
    )
}

export default Home;