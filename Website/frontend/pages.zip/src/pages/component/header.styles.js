import styled from "styled-components";

export const StyledHeader = styled.div`
/*Styles for header*/
@import url("https://candyfonts.com/wp-data/2018/10/26/11538/HELR45W.ttf");
*{
    font-family: 'helvetica';
    display: flex;
    justify-content: center;
}

  .header {
    display:flex;  
    justify-content: space-between;
    max-width: 100%;
    margin: 0 auto;
    height: 4.5vw; /* Changed to relative unit */
    background-color: #D179FF;

  }

 .header_logo{
  display: flex;
  justify-content: center;
    margin-left: 2vw; /* Changed to relative unit */
    margin-top: 0; /* Changed to relative unit */
}


  .header_logo li {
    display: flex;
    justify-content: center;
    position: relative;
    overflow-x: scroll;
    font-weight: bolder;
    font-size: 2vw; /* Changed to relative unit */
     /* Changed to relative unit */
    margin-top: 2vh; /* Changed to relative unit */
    margin-left: 34vw;
  }

  
  .logo {
    display:flex;
    
    gap: 2.5vw; /* Changed to relative unit */
    font-size: 1.4vw; /* Changed to relative unit */
    margin-right: 2vw; /* Changed to relative unit */
    margin-top: 2.2vw; /* Changed to relative unit */
  }
`
