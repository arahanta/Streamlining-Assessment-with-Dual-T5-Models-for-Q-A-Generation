import styled from 'styled-components';

// Define your styled component
export const StyledMono = styled.div`
/* Styles for monologue */
@import url("https://candyfonts.com/wp-data/2018/10/26/11538/HELR45W.ttf");
*{
    font-family: 'helvetica';
}

.mono {
    margin-left: 450px;
    margin-top: -40px;
    margin-right: 300px;
    text-align: justify;
}  
`;