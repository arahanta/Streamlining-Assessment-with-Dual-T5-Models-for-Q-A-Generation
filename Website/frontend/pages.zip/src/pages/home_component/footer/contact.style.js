import styled from 'styled-components';

// Define your styled components
export const StyledContact = styled.div`
    /* Styles for contact */
@import url("https://candyfonts.com/wp-data/2018/10/26/11538/HELR45W.ttf");
*{
    font-family: 'helvetica';
}
    
.contact {
    margin-left: 1150px;
    margin-top: -90px;
}

.contact p{
    margin-top: -23px;
    margin-left: 35px;
}
`;

export const StyledMail = styled.div`
    /* Styles for mail */
@import url("https://candyfonts.com/wp-data/2018/10/26/11538/HELR45W.ttf");
*{
    font-family: 'helvetica';
}

.mail {
    margin-left: 1150px;
    border-radius: 20px;
    position: relative;
    display: inline-flex;
    overflow: auto;
}

.mail_address{
    margin-left: 1185px;
    margin-top: -33px;
}
`;
