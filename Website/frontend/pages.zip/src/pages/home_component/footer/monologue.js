import { StyledMono } from "./monologue.style.js";

// Styled component version of the footer info component
const FooterInfo = () => {
    return (
        <StyledMono>
            <div className="mono">
                <p>Unleash the power of curiosity with our question answering app, where every inquiry sparks a journey towards knowledge.</p>
            </div>
        </StyledMono>
    );
}

export default FooterInfo;
