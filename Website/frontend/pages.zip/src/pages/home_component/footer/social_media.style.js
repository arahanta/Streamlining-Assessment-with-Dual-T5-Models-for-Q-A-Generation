import styled from 'styled-components';

// Define your styled component
export const StyledSocialMedia = styled.div`
    .social_media {
        /* Styles for social_media */
        display: flex;
        align-items: center;
        margin-left: 50px;
        margin-top: 15px;
        gap: 15px;
    }
`;