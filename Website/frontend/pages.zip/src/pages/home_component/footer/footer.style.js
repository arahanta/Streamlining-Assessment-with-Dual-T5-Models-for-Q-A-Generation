import styled from 'styled-components';

// Define your styled component
export const StyledFooter = styled.div`
/* Styles for the footer section */
@import url("https://candyfonts.com/wp-data/2018/10/26/11538/HELR45W.ttf");
*{
    font-family: 'helvetica';
}    
    .footer {
        /* styles for footer */
        display:flex;  
        max-width: 100%;
        margin: 0 auto;
        height: 150px;
        background-color: #D179FF;
    }

    .heading {
        /* styles for heading */
        font-weight: bolder;
        font-size: 35px;
        margin-left: 130px;
        margin-top: 15px;
    }
`;