import { StyledFooter } from "./footer.style.js";

// Styled component version of the footer component
const Footer = () => {
    return (
        <StyledFooter>
            <div className="footer">
                <nav className="heading">
                    <p>Edu Pulse</p>
                </nav>
            </div>
        </StyledFooter>
    );
}

export default Footer;
