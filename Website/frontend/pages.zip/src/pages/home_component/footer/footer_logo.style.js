import styled from 'styled-components';

// Define your styled component
export const StyledFooterLogo = styled.div`
    .footer_logo {
        /* Styles for footer logo */
        margin-left: 30px;
        margin-top: -135px;
    }

    img {
        height: 50px; /* height */
    }
`;