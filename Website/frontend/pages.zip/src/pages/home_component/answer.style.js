import styled from 'styled-components';

// Styled component
export const StyledAnswerBox = styled.div`
    /* Styles for the answer box */
@import url("https://candyfonts.com/wp-data/2018/10/26/11538/HELR45W.ttf");
*{
    font-family: 'helvetica';
}
  
&.answer_box{
    width: 380px;
    height: 480px;
    position: relative;
    margin: 0% auto;
    background: #fff;
    padding: 5px;
    overflow: hidden;
}
`;