import { StyledBox } from "./question.style.js";

// Styled component version of the Question component
const Question = () => {
    return (
        <StyledBox className="box">
            {/* Content of the box */}
        </StyledBox>
    );
}

export default Question;
