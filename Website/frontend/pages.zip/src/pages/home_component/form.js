import React, { useState } from 'react';
import axios from 'axios';
import { FormContainer, FormGroup, Label, Input, Button, TextArea } from './form.style';

const Form = () => {
  const [formdata, setFormdata] = useState({ paragraph: '', no: 3, length: 50 });
  const [questions, setQuestions] = useState([]);
  const [userAnswers, setUserAnswers] = useState([]);
  const [modelAnswers, setModelAnswers] = useState([]);
  const [similarityScores, setSimilarityScores] = useState([]);
  const [submitted, setSubmitted] = useState(false);

  const handleChange = (e) => {
    setFormdata({ ...formdata, [e.target.id]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    axios.post('http://127.0.0.1:5000/home', {
      context: formdata.paragraph,
      Number: formdata.no,
      length: formdata.length
    })
    .then(function (response) {
      const data = response.data;
      setQuestions(data.generated_questions);
      setModelAnswers(data.model_answers);
      setUserAnswers(new Array(data.generated_questions.length).fill(''));
    })
    .catch(function (error) {
      console.log(error);
    });
  };

  const handleAnswerChange = (index, e) => {
    const newAnswers = [...userAnswers];
    newAnswers[index] = e.target.value;
    setUserAnswers(newAnswers);
  };

  const submitAnswers = () => {
    axios.post('http://127.0.0.1:5000/result', {
      User_Entered_Answer: userAnswers,
      Model_Given_Answer: modelAnswers
    })
    .then(function (response) {
      const data = response.data;
      console.log(data.Similarity)
      setSimilarityScores(data.Similarity || []); // Ensure default value is set in case of undefined data
      setSubmitted(true);
    })
    .catch(function (error) {
      console.log(error);
    });
};

  const resetFunction = () => {
    setQuestions([]);
    setUserAnswers([]);
    setModelAnswers([]);
    setSimilarityScores([]);
    setSubmitted(false);
  };

  return (
    <FormContainer>
      <form onSubmit={handleSubmit}>
        <FormGroup>
          <Label>Enter the paragraph </Label>
          <TextArea id='paragraph' value={formdata.paragraph} onChange={handleChange} rows={5} />
        </FormGroup>
        <FormGroup>
          <Label>Enter the no of question </Label>
          <Input type='number' id='no' value={formdata.no} onChange={handleChange} />
        </FormGroup>
        <FormGroup>
          <Label>Enter the length of answer </Label>
          <Input type='number' id='length' value={formdata.length} onChange={handleChange} />
          <Button type='submit'>Get Questions</Button>
        </FormGroup>
      </form>

      <Button onClick={resetFunction}>Reset</Button>

      {questions.length > 0 && !submitted && (
        <div>
          <h2>Questions</h2>
          {questions.map((question, index) => (
            <div key={index}>
              <p><strong>Question:</strong> {question}</p>
              <Input
                type='text'
                placeholder='Type your answer here...'
                value={userAnswers[index] || ''}
                onChange={(e) => handleAnswerChange(index, e)}
              />
            </div>
          ))}
          <Button onClick={submitAnswers}>Submit Answers</Button>
        </div>
      )}

      {submitted && (
        <div>
          <h2>Questions and Answers</h2>
          {questions.map((question, index) => (
            <div key={index}>
              <p><strong>Question:</strong> {question}</p>
              <p><strong>User Answer:</strong> {userAnswers[index]}</p>
              <p><strong>Model Answer:</strong> {modelAnswers[index]}</p>
              <p><strong>Similarity Score:</strong> {similarityScores[index]}</p>
              <hr />
            </div>
          ))}
        </div>
      )}
    </FormContainer>
  );
};

export default Form;
