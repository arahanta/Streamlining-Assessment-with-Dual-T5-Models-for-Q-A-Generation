import styled from 'styled-components';

// Styled component
export const StyledButtonContainer = styled.div`
    /* Styles for the button container */
@import url("https://candyfonts.com/wp-data/2018/10/26/11538/HELR45W.ttf");
*{
    font-family: 'helvetica';
}

    &.btn1{
        background: #D179FF;
        border-radius: 15px;
        width: 140px;
        margin: 22px auto;
        position: relative;
        text-align: center;
    }
    
    .btn:hover {
        background-color: #9D53E3;
        border-radius: 15px;
    }
`;

export const StyledButton = styled.button`
    /* Styles for the button */
`;