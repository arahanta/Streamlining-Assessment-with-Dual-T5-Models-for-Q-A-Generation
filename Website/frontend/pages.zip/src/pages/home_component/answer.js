import { StyledAnswerBox } from "./answer.style.js";

// Styled component version of the Answer1 component
const Answer1 = () => {
    return (
        <StyledAnswerBox className="answer_box">
            {/* Content of the answer box */}
        </StyledAnswerBox>
    );
}

export default Answer1;
